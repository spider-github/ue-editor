# @ue/vue2-ueditor-plus

Vue 2 wrapper for UEditorPlus with asset copy CLI.

## Install

```bash
npm install vue axios @ue/vue2-ueditor-plus @ue/ueditor-plus-assets
```

## Copy static assets

```bash
npx @ue/vue2-ueditor-plus copy-assets public/static/ueditor-plus
```

## Usage

```js
import Vue from 'vue'
import UeEditor from '@ue/vue2-ueditor-plus'
import '@ue/vue2-ueditor-plus/style.css'

Vue.use(UeEditor)
```

```vue
<template>
  <UeEditor
    v-model="content"
    base-url="/static/ueditor-plus/"
    upload-url="/api/upload"
  />
</template>
```
